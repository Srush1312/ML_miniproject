# Stone Motion Simulation — OOMD Mini Project

An interactive browser-based simulation that demonstrates why a stone thrown vertically upward returns to the ground under Earth's gravity.

## Features
- Animated stone trajectory
- Adjustable initial velocity (5–30 m/s)
- Start, pause, and reset controls
- Live height, velocity, time, and acceleration readings
- Calculated maximum height, time to the top, and total flight time
- Explanations for upward motion, highest point, and falling motion
- No installation, backend, API key, or build step required

## Run locally
1. Extract the ZIP file.
2. Open `index.html` in a modern browser.
3. Click **Throw stone**.

If your browser restricts local files, run a local server from this folder:
- Python: `python -m http.server 8000`
- Then open `http://localhost:8000`

## Deploy free with GitHub Pages
1. Create or sign in to a GitHub account.
2. Create a new repository, for example `stone-motion-simulation`.
3. Upload `index.html`, `style.css`, and `script.js` (README can also be uploaded).
4. Open the repository's **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**.
6. Select branch `main` and folder `/ (root)`, then Save.
7. Wait for the deployment link to appear in the Pages section.

## Deploy with Netlify
1. Extract the ZIP file.
2. Open Netlify and choose the option to add a new site by deploying manually.
3. Drag the extracted project folder (containing `index.html`, `style.css`, and `script.js`) into the deploy area.
4. Open the generated website URL.

## OOMD model represented in code
The JavaScript uses classes to separate responsibilities:
- `Stone`: holds initial velocity, current height, current velocity, and elapsed time.
- `PhysicsEngine`: provides motion equation helpers.
- `SimulationController`: controls start, pause, reset, and the fixed-step simulation.
- `SimulationView`: draws the stone and the scene on a canvas.

## Physics model
Upward is positive; air resistance is ignored.
- `v = u - gt`
- `h = ut - 0.5gt²`
- `H = u² / (2g)`
- `t_top = u / g`
- `t_flight = 2u / g`

where `u` is initial velocity, `g = 9.8 m/s²`, `t` is elapsed time, `v` is vertical velocity, `h` is height above the launch point, and `H` is maximum height.

## Before submission
- Add your name, roll number, class, college, and guide name to the report or project page if required.
- Capture screenshots of the working simulation.
- Draw/export the required OOMD UML diagrams in StarUML and include them in the report.
- Verify the project with your faculty's rubric. This is a ready-to-run educational prototype, not a substitute for your own review or viva preparation.
