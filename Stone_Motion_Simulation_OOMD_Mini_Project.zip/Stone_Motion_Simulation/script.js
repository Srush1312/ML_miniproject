(() => {
  'use strict';
  const G = 9.8;
  const canvas = document.getElementById('scene');
  const ctx = canvas.getContext('2d');
  const velocityInput = document.getElementById('velocity');
  const velocityLabel = document.getElementById('velocityLabel');
  const heightValue = document.getElementById('heightValue');
  const currentVelocity = document.getElementById('currentVelocity');
  const timeValue = document.getElementById('timeValue');
  const maxHeightEl = document.getElementById('maxHeight');
  const topTimeEl = document.getElementById('topTime');
  const flightTimeEl = document.getElementById('flightTime');
  const statusEl = document.getElementById('status');
  const phaseTitle = document.getElementById('phaseTitle');
  const phaseText = document.getElementById('phaseText');
  const throwBtn = document.getElementById('throwBtn');
  const pauseBtn = document.getElementById('pauseBtn');
  const resetBtn = document.getElementById('resetBtn');

  // OOMD model classes: Stone, PhysicsEngine, SimulationController and SimulationView.
  class Stone {
    constructor(initialVelocity) { this.initialVelocity = initialVelocity; this.reset(); }
    reset() { this.time = 0; this.height = 0; this.velocity = this.initialVelocity; this.finished = false; }
    update(dt) {
      this.time += dt;
      this.height = Math.max(0, this.initialVelocity * this.time - 0.5 * G * this.time * this.time);
      this.velocity = this.initialVelocity - G * this.time;
      if (this.height <= 0 && this.time > 0) { this.height = 0; this.velocity = 0; this.finished = true; }
    }
    get maxHeight() { return this.initialVelocity ** 2 / (2 * G); }
    get timeToTop() { return this.initialVelocity / G; }
    get flightTime() { return (2 * this.initialVelocity) / G; }
  }
  class PhysicsEngine {
    static heightAt(u, t) { return Math.max(0, u * t - 0.5 * G * t * t); }
    static velocityAt(u, t) { return u - G * t; }
  }
  class SimulationController {
    constructor() { this.stone = new Stone(Number(velocityInput.value)); this.running = false; this.lastFrame = 0; this.accumulator = 0; this.step = 1 / 120; this.frame = this.frame.bind(this); }
    start() {
      if (this.stone.finished) this.stone = new Stone(Number(velocityInput.value));
      if (this.running) return;
      this.running = true; this.lastFrame = 0; this.accumulator = 0;
      statusEl.textContent = 'Running'; throwBtn.disabled = true; pauseBtn.disabled = false; pauseBtn.textContent = 'Ⅱ Pause';
      phaseTitle.textContent = 'Stone moving upward'; phaseText.textContent = 'Gravity acts downward, opposite to the initial upward movement. The stone loses upward speed each second.';
      requestAnimationFrame(this.frame);
    }
    togglePause() {
      if (!this.running) return;
      this.running = false; statusEl.textContent = 'Paused'; throwBtn.disabled = false; pauseBtn.disabled = true;
      phaseTitle.textContent = 'Simulation paused'; phaseText.textContent = 'Resume by pressing “Throw stone”. The current position and measurements are preserved.';
    }
    reset() {
      this.running = false; this.stone = new Stone(Number(velocityInput.value));
      throwBtn.disabled = false; pauseBtn.disabled = true; pauseBtn.textContent = 'Ⅱ Pause'; statusEl.textContent = 'Ready';
      phaseTitle.textContent = 'Ready to throw'; phaseText.textContent = 'Choose an initial velocity and press “Throw stone” to begin the simulation.';
      this.updateMeasurements(); view.draw(this.stone);
    }
    frame(timestamp) {
      if (!this.running) return;
      if (!this.lastFrame) this.lastFrame = timestamp;
      const delta = Math.min((timestamp - this.lastFrame) / 1000, 0.05);
      this.lastFrame = timestamp; this.accumulator += delta;
      while (this.accumulator >= this.step && !this.stone.finished) {
        this.stone.update(this.step); this.accumulator -= this.step;
      }
      this.updateMeasurements(); view.draw(this.stone);
      if (this.stone.finished) {
        this.running = false; statusEl.textContent = 'Landed'; throwBtn.disabled = false; pauseBtn.disabled = true;
        phaseTitle.textContent = 'Stone reached the ground'; phaseText.textContent = 'Gravity accelerated the stone downward. It returned to its starting height because the simulation neglects air resistance.';
        return;
      }
      if (this.stone.velocity <= 0 && this.stone.time <= this.stone.timeToTop + 0.08) {
        phaseTitle.textContent = 'At the highest point'; phaseText.textContent = 'The vertical velocity is momentarily zero, but gravity still acts downward. The stone immediately begins falling.';
      } else if (this.stone.velocity < 0) {
        phaseTitle.textContent = 'Stone falling down'; phaseText.textContent = 'The stone is moving downward and its downward speed is increasing due to gravity.';
      }
      requestAnimationFrame(this.frame);
    }
    updateMeasurements() {
      const s = this.stone;
      heightValue.innerHTML = `${s.height.toFixed(2)} <small>m</small>`;
      currentVelocity.innerHTML = `${s.velocity.toFixed(2)} <small>m/s</small>`;
      timeValue.innerHTML = `${s.time.toFixed(2)} <small>s</small>`;
    }
  }
  class SimulationView {
    resize() {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.max(1, window.devicePixelRatio || 1);
      canvas.width = Math.round(rect.width * dpr); canvas.height = Math.round(rect.height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      this.width = rect.width; this.height = rect.height;
    }
    draw(stone) {
      this.resize();
      const w = this.width, h = this.height;
      ctx.clearRect(0, 0, w, h);
      const ground = h - 36, top = 28, maxH = Math.max(stone.maxHeight, 1);
      const usable = ground - top;
      const scale = usable / (maxH * 1.2);
      const x = w * 0.48, y = ground - stone.height * scale;
      // Subtle horizontal grid and height labels.
      ctx.lineWidth = 1; ctx.strokeStyle = '#e8edf5'; ctx.fillStyle = '#8b95a7'; ctx.font = '10px system-ui';
      for (let i = 0; i <= 4; i++) {
        const gy = top + (usable * i / 4);
        ctx.beginPath(); ctx.moveTo(15, gy); ctx.lineTo(w - 15, gy); ctx.stroke();
      }
      ctx.strokeStyle = '#8e9bb0'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(15, ground); ctx.lineTo(w - 15, ground); ctx.stroke();
      ctx.fillStyle = '#68758a'; ctx.fillText('GROUND LEVEL', 20, ground + 18);
      // Dashed trajectory guide and maximum-height marker.
      const topY = ground - stone.maxHeight * scale;
      ctx.setLineDash([4, 5]); ctx.strokeStyle = '#b7c6e8'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(x, ground); ctx.lineTo(x, topY); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = '#6f7f9b'; ctx.font = '11px system-ui'; ctx.fillText(`Max: ${stone.maxHeight.toFixed(1)} m`, Math.min(x + 15, w - 105), Math.max(topY + 12, 16));
      // Stone shadow and stone body.
      ctx.beginPath(); ctx.ellipse(x, ground + 1, 15, 4, 0, 0, Math.PI * 2); ctx.fillStyle = '#dce2ec'; ctx.fill();
      const grad = ctx.createRadialGradient(x - 5, y - 6, 2, x, y, 15);
      grad.addColorStop(0, '#ffca91'); grad.addColorStop(1, '#d76b28');
      ctx.beginPath(); ctx.arc(x, y, 12, 0, Math.PI * 2); ctx.fillStyle = grad; ctx.fill();
      ctx.strokeStyle = '#b75b22'; ctx.lineWidth = 1.5; ctx.stroke();
      // Gravity arrow.
      if (!stone.finished) {
        ctx.strokeStyle = '#2457d6'; ctx.fillStyle = '#2457d6'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(x + 31, y - 23); ctx.lineTo(x + 31, y + 7); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(x + 25, y + 1); ctx.lineTo(x + 31, y + 8); ctx.lineTo(x + 37, y + 1); ctx.closePath(); ctx.fill();
        ctx.font = '11px system-ui'; ctx.fillText('g', x + 40, y - 3);
      }
      // Motion label.
      ctx.fillStyle = '#25324a'; ctx.font = '600 11px system-ui';
      const label = stone.finished ? 'Landed' : (stone.velocity > 0.05 ? 'Moving up ↑' : (stone.velocity < -0.05 ? 'Falling down ↓' : 'Highest point'));
      ctx.fillText(label, Math.min(x + 48, w - 105), Math.max(18, y - 16));
    }
  }
  const view = new SimulationView();
  const controller = new SimulationController();

  function updatePredictions() {
    const u = Number(velocityInput.value);
    velocityLabel.textContent = u;
    maxHeightEl.textContent = `${(u * u / (2 * G)).toFixed(2)} m`;
    topTimeEl.textContent = `${(u / G).toFixed(2)} s`;
    flightTimeEl.textContent = `${(2 * u / G).toFixed(2)} s`;
    if (!controller.running && controller.stone.time === 0) {
      controller.stone = new Stone(u);
      controller.updateMeasurements(); view.draw(controller.stone);
    }
  }
  velocityInput.addEventListener('input', updatePredictions);
  throwBtn.addEventListener('click', () => controller.start());
  pauseBtn.addEventListener('click', () => controller.togglePause());
  resetBtn.addEventListener('click', () => controller.reset());
  window.addEventListener('resize', () => view.draw(controller.stone));
  updatePredictions();
  view.draw(controller.stone);
})();